var searchData=
[
  ['mouse_20buttons',['Mouse buttons',['../group__buttons.html',1,'']]],
  ['modifier_20key_20flags',['Modifier key flags',['../group__mods.html',1,'']]],
  ['monitor_20handling',['Monitor handling',['../group__monitor.html',1,'']]]
];
